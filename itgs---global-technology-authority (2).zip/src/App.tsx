import { motion, useScroll, useSpring } from 'motion/react';
import { Shield, Globe, Zap, Users, BarChart3, ArrowRight, Menu, X, Cpu, Network, Search, Target, Code, Smartphone, Layout, Palette, Headphones } from 'lucide-react';
import React, { useState, useEffect } from 'react';

// --- Data ---

const SERVICES_DATA = [
  {
    id: "digital-marketing",
    title: "Digital Marketing",
    icon: <Target size={36} />,
    shortDesc: "Strategic multi-channel marketing campaigns designed to scale your brand's global presence.",
    overview: "Our digital marketing strategy is built on psychological triggers and data-driven insights. We don't just run ads; we engineer ecosystems that convert high-value prospects into loyal advocates.",
    process: [
      { step: "Audit", desc: "Deep analysis of your current market position and competitor landscape." },
      { step: "Strategy", desc: "Crafting a bespoke multi-channel roadmap aligned with your business goals." },
      { step: "Execution", desc: "Deploying high-impact campaigns across Search, Social, and Display." },
      { step: "Optimization", desc: "Continuous A/B testing and performance tuning to maximize ROI." }
    ],
    features: ["Performance Marketing", "Content Strategy", "Social Media Management", "Email Automation"],
    results: "340% average increase in qualified lead volume for enterprise clients within 6 months.",
    tools: ["Google Ads", "Meta Business Suite", "HubSpot", "Semrush"]
  },
  {
    id: "seo",
    title: "Search Engine Optimization",
    icon: <Search size={36} />,
    shortDesc: "Dominating search results with advanced technical SEO and authority-building strategies.",
    overview: "SEO at ITGS is about more than just rankings; it's about visibility and authority. We optimize your technical foundation and content architecture to ensure you own the conversation in your industry.",
    process: [
      { step: "Technical Audit", desc: "Identifying and fixing crawlability, indexing, and speed issues." },
      { step: "Keyword Research", desc: "Mapping high-intent search terms to your customer journey." },
      { step: "On-Page SEO", desc: "Optimizing content structure, metadata, and internal linking." },
      { step: "Authority Building", desc: "Strategic backlink acquisition from high-authority domains." }
    ],
    features: ["Technical SEO", "Local & Global SEO", "Content Optimization", "Competitor Analysis"],
    results: "Achieved #1 rankings for 50+ high-competition industry keywords for a Fortune 500 client.",
    tools: ["Ahrefs", "Google Search Console", "Screaming Frog", "SurferSEO"]
  },
  {
    id: "lead-generation",
    title: "Lead Generation",
    icon: <Users size={36} />,
    shortDesc: "High-precision lead acquisition systems that fill your pipeline with ready-to-buy prospects.",
    overview: "We build automated lead generation engines that work 24/7. By combining psychological profiling with advanced targeting, we deliver prospects that are already primed for your sales team.",
    process: [
      { step: "Profiling", desc: "Defining your Ideal Customer Profile (ICP) based on behavioral data." },
      { step: "Funnel Design", desc: "Building high-converting landing pages and lead magnets." },
      { step: "Traffic Acquisition", desc: "Driving targeted traffic through paid and organic channels." },
      { step: "Nurturing", desc: "Automated follow-up sequences to qualify and warm up leads." }
    ],
    features: ["B2B Lead Gen", "LinkedIn Outreach", "Funnel Optimization", "CRM Integration"],
    results: "Generated over $50M in attributed pipeline for B2B SaaS clients in the last year.",
    tools: ["Apollo.io", "Salesforce", "Instantly.ai", "Unbounce"]
  },
  {
    id: "web-development",
    title: "Web Development",
    icon: <Code size={36} />,
    shortDesc: "Enterprise-grade web applications built for speed, security, and infinite scalability.",
    overview: "We don't just build websites; we build digital assets. Our development team focuses on clean code, high performance, and robust security to ensure your platform can handle global traffic without friction.",
    process: [
      { step: "Architecture", desc: "Planning the technical stack and database structure for scale." },
      { step: "Development", desc: "Agile coding with a focus on modularity and performance." },
      { step: "Testing", desc: "Rigorous QA, including security audits and load testing." },
      { step: "Deployment", desc: "CI/CD pipelines for seamless, zero-downtime releases." }
    ],
    features: ["Custom Web Apps", "E-commerce Solutions", "Headless CMS", "API Integrations"],
    results: "Reduced page load times by 65% for a global retailer, leading to a 22% increase in conversions.",
    tools: ["React / Next.js", "Node.js", "AWS / Vercel", "PostgreSQL"]
  },
  {
    id: "mobile-development",
    title: "Mobile App Development",
    icon: <Smartphone size={36} />,
    shortDesc: "Native and cross-platform mobile experiences that keep your brand in your customers' pockets.",
    overview: "Mobile is the primary touchpoint for modern users. We create intuitive, high-performance mobile applications that leverage native capabilities to provide a seamless user experience.",
    process: [
      { step: "Prototyping", desc: "Interactive wireframes to validate user flows and features." },
      { step: "Development", desc: "Building with React Native or Flutter for cross-platform efficiency." },
      { step: "Integration", desc: "Connecting with backend APIs and third-party services." },
      { step: "App Store Launch", desc: "Handling the full submission and optimization process." }
    ],
    features: ["iOS & Android", "Cross-Platform", "Real-time Features", "Offline Functionality"],
    results: "Launched a fintech app that reached 100k active users within the first 3 months.",
    tools: ["React Native", "Flutter", "Firebase", "Swift / Kotlin"]
  },
  {
    id: "ui-ux-design",
    title: "UI/UX Design",
    icon: <Layout size={36} />,
    shortDesc: "Psychology-driven interfaces designed to maximize user engagement and trust.",
    overview: "Design at ITGS is a science. We use behavioral psychology and user testing to create interfaces that guide users naturally toward your desired outcomes while building brand authority.",
    process: [
      { step: "Research", desc: "User interviews and competitive benchmarking." },
      { step: "Wireframing", desc: "Mapping out the structural layout and user journey." },
      { step: "Visual Design", desc: "Applying brand identity and high-fidelity UI elements." },
      { step: "Prototyping", desc: "High-fidelity interactive demos for user validation." }
    ],
    features: ["User Research", "Interface Design", "Experience Mapping", "Design Systems"],
    results: "Redesigned a complex dashboard resulting in a 40% reduction in user support tickets.",
    tools: ["Figma", "Adobe XD", "Principle", "Maze"]
  },
  {
    id: "graphic-design",
    title: "Graphic Design",
    icon: <Palette size={36} />,
    shortDesc: "Bold visual identities that communicate authority and set your brand apart.",
    overview: "Visual communication is the first step in building trust. We create cohesive brand identities and marketing assets that reflect your company's global credibility and innovative spirit.",
    process: [
      { step: "Discovery", desc: "Understanding your brand values and target audience." },
      { step: "Concepting", desc: "Developing multiple creative directions and moodboards." },
      { step: "Design", desc: "Refining the chosen direction into final assets." },
      { step: "Delivery", desc: "Providing a complete kit of production-ready files." }
    ],
    features: ["Brand Identity", "Marketing Collateral", "Social Media Assets", "Presentation Design"],
    results: "Created a visual identity for a tech startup that helped them secure $10M in Series A funding.",
    tools: ["Adobe Creative Suite", "Canva Enterprise", "Midjourney", "After Effects"]
  },
  {
    id: "virtual-assistance",
    title: "Virtual Assistance",
    icon: <Headphones size={36} />,
    shortDesc: "Elite administrative and operational support to free up your executive bandwidth.",
    overview: "Our virtual assistants are more than just support; they are operational partners. We provide highly trained professionals who handle the details so you can focus on high-level strategy.",
    process: [
      { step: "Matching", desc: "Pairing you with an assistant that fits your specific needs." },
      { step: "Onboarding", desc: "Integrating the assistant into your workflows and tools." },
      { step: "Execution", desc: "Daily management of tasks, scheduling, and operations." },
      { step: "Reporting", desc: "Weekly updates on progress and task completion." }
    ],
    features: ["Executive Support", "Data Entry", "Customer Support", "Project Management"],
    results: "Saved an average of 15 hours per week for C-level executives in our pilot program.",
    tools: ["Slack", "Asana / Trello", "Google Workspace", "Calendly"]
  },
  {
    id: "e-commerce",
    title: "E-commerce Solutions",
    icon: <Globe size={36} />,
    shortDesc: "Comprehensive e-commerce management including Amazon, eBay, and Shopify optimization.",
    overview: "Our e-commerce solutions are designed to dominate global marketplaces. From product sourcing to wholesale management, we provide the technical and operational expertise to scale your online retail business.",
    process: [
      { step: "Sourcing", desc: "Identifying high-margin products and reliable global suppliers." },
      { step: "Setup", desc: "Configuring Amazon, eBay, and Shopify stores for maximum conversion." },
      { step: "Optimization", desc: "Advanced listing optimization and PPC management." },
      { step: "Scaling", desc: "Implementing dropshipping and wholesale models for rapid growth." }
    ],
    features: ["Amazon & eBay Management", "Shopify Development", "Product Sourcing", "Dropshipping", "Amazon Wholesale"],
    results: "Managed over $10M in annual GMV for e-commerce partners with a 25% average margin improvement.",
    tools: ["Amazon Seller Central", "Shopify Plus", "Helium 10", "AutoDS"]
  }
];

// --- Components ---

const Logo = () => (
  <div className="flex items-center gap-3 group">
    <div className="relative w-12 h-12 flex items-center justify-center">
      {/* Outer Rotating Ring */}
      <motion.div 
        animate={{ rotate: 360 }}
        transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
        className="absolute inset-0 border-2 border-dashed border-cyan/30 rounded-xl"
      />
      {/* Inner Shield/Node */}
      <div className="relative w-9 h-9 bg-electric rounded-lg flex items-center justify-center glow-cyan transform group-hover:rotate-12 transition-transform duration-500">
        <Network size={20} className="text-white" />
      </div>
      {/* Floating Particles */}
      <motion.div 
        animate={{ y: [-2, 2, -2], x: [-2, 2, -2] }}
        transition={{ duration: 3, repeat: Infinity }}
        className="absolute -top-1 -right-1 w-2 h-2 bg-cyan rounded-full shadow-[0_0_10px_#00C2FF]"
      />
    </div>
    <div className="flex flex-col">
      <span className="text-white font-display text-2xl font-black tracking-tighter leading-none">ITGS</span>
      <span className="text-cyan text-[8px] uppercase tracking-[0.4em] font-bold mt-1">Global Authority</span>
    </div>
  </div>
);

const Navbar = ({ activePage, setActivePage }: { activePage: string, setActivePage: (page: string) => void }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = ['Home', 'About', 'Services', 'Reviews', 'Team', 'Blog', 'Careers'];

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${isScrolled ? 'glass-nav py-3' : 'bg-transparent py-8'}`}>
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        <div 
          className="cursor-pointer" 
          onClick={() => setActivePage('Home')}
        >
          <Logo />
        </div>

        {/* Desktop Menu */}
        <div className="hidden md:flex items-center gap-10">
          {navLinks.map((link) => (
            <button
              key={link}
              onClick={() => setActivePage(link)}
              className={`text-sm font-bold uppercase tracking-widest transition-all duration-300 hover:text-cyan relative group ${activePage === link ? 'text-cyan' : 'text-white/60'}`}
            >
              {link}
              <span className={`absolute -bottom-2 left-0 w-0 h-0.5 bg-cyan transition-all duration-300 group-hover:w-full ${activePage === link ? 'w-full' : ''}`} />
            </button>
          ))}
          <button 
            onClick={() => setActivePage('Booking')}
            className="bg-electric hover:bg-cyan text-white px-6 py-2.5 rounded-full text-xs font-bold uppercase tracking-widest transition-all duration-300 shadow-lg shadow-electric/20 flex items-center justify-center"
          >
            Schedule Meeting
          </button>
        </div>

        {/* Mobile Toggle */}
        <button className="md:hidden text-white p-2" onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
          {isMobileMenuOpen ? <X size={32} /> : <Menu size={32} />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <motion.div 
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          className="md:hidden bg-midnight border-b border-white/5 p-8 flex flex-col gap-6"
        >
          {navLinks.map((link) => (
            <button
              key={link}
              onClick={() => {
                setActivePage(link);
                setIsMobileMenuOpen(false);
              }}
              className={`text-left text-2xl font-black tracking-tighter ${activePage === link ? 'text-cyan' : 'text-white/60'}`}
            >
              {link}
            </button>
          ))}
          <button 
            onClick={() => {
              setActivePage('Booking');
              setIsMobileMenuOpen(false);
            }}
            className="bg-electric text-white py-4 rounded-xl font-bold uppercase tracking-widest text-sm mt-4 flex items-center justify-center"
          >
            Schedule Meeting
          </button>
        </motion.div>
      )}
    </nav>
  );
};

const TechVisual = () => {
  return (
    <div className="relative w-full h-[600px] flex items-center justify-center perspective-1000">
      {/* Background Matrix/Grid Effect */}
      <div className="absolute inset-0 opacity-10 overflow-hidden">
        <div className="grid grid-cols-12 gap-1 w-full h-full">
          {[...Array(144)].map((_, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0.1 }}
              animate={{ opacity: [0.1, 0.3, 0.1] }}
              transition={{ duration: 2 + Math.random() * 3, repeat: Infinity }}
              className="border-[0.5px] border-cyan/20 h-12"
            />
          ))}
        </div>
      </div>

      {/* Central Neural Hub */}
      <motion.div
        style={{ transformStyle: "preserve-3d" }}
        animate={{ 
          rotateY: [0, 360],
          rotateX: [0, 10, 0]
        }}
        transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
        className="relative z-20 w-48 h-48"
      >
        {/* Hub Core */}
        <div className="absolute inset-0 bg-midnight/80 border-2 border-cyan/40 rounded-full flex items-center justify-center shadow-[0_0_50px_rgba(0,194,255,0.3)]">
          <div className="relative w-32 h-32">
            <motion.div
              animate={{ scale: [1, 1.2, 1], opacity: [0.5, 1, 0.5] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="absolute inset-0 bg-cyan/10 rounded-full blur-xl"
            />
            <Globe className="text-cyan w-full h-full p-6 animate-pulse" />
          </div>
        </div>

        {/* Orbiting Data Rings */}
        {[...Array(3)].map((_, i) => (
          <motion.div
            key={i}
            animate={{ rotateZ: 360 }}
            transition={{ duration: 10 + i * 5, repeat: Infinity, ease: "linear" }}
            className="absolute inset-[-20px] border border-cyan/20 rounded-full"
            style={{ rotateX: `${45 + i * 15}deg`, rotateY: `${i * 30}deg` }}
          />
        ))}
      </motion.div>

      {/* Neural Nodes & Connections */}
      <div className="absolute inset-0 pointer-events-none">
        {[...Array(12)].map((_, i) => {
          const angle = (i / 12) * Math.PI * 2;
          const x = Math.cos(angle) * 220;
          const y = Math.sin(angle) * 220;
          
          return (
            <div key={i} className="absolute top-1/2 left-1/2" style={{ transform: `translate(${x}px, ${y}px)` }}>
              <motion.div
                animate={{ 
                  scale: [1, 1.3, 1],
                  boxShadow: ["0 0 0px rgba(0,194,255,0)", "0 0 15px rgba(0,194,255,0.5)", "0 0 0px rgba(0,194,255,0)"]
                }}
                transition={{ duration: 3, delay: i * 0.2, repeat: Infinity }}
                className="w-3 h-3 bg-cyan rounded-full"
              />
              
              {/* Connection Line to Hub */}
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: 220 }}
                transition={{ duration: 1, delay: i * 0.1 }}
                className="absolute top-1.5 right-1.5 h-[1px] bg-gradient-to-l from-cyan/50 to-transparent origin-right"
                style={{ transform: `rotate(${angle + Math.PI}rad)` }}
              />
            </div>
          );
        })}
      </div>

      {/* Scanning Beam */}
      <motion.div
        animate={{ top: ["0%", "100%", "0%"] }}
        transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
        className="absolute left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-cyan/40 to-transparent z-30 blur-sm"
      />

      {/* Floating Terminal Snippets */}
      <motion.div
        animate={{ y: [0, -15, 0], x: [0, 10, 0] }}
        transition={{ duration: 7, repeat: Infinity }}
        className="absolute top-20 right-0 bg-midnight/90 border border-white/10 p-3 rounded-lg text-[9px] font-mono text-cyan shadow-2xl"
      >
        <div className="flex gap-2 mb-1 border-b border-white/5 pb-1">
          <div className="w-2 h-2 rounded-full bg-red-500/50" />
          <div className="w-2 h-2 rounded-full bg-yellow-500/50" />
          <div className="w-2 h-2 rounded-full bg-green-500/50" />
        </div>
        <div>$ itgs --status</div>
        <div className="text-white/60">{" > "} uptime: 99.999%</div>
        <div className="text-white/60">{" > "} security: active</div>
        <div className="text-electric">{" > "} nodes: 1,240 online</div>
      </motion.div>

      <motion.div
        animate={{ y: [0, 15, 0], x: [0, -10, 0] }}
        transition={{ duration: 8, repeat: Infinity }}
        className="absolute bottom-20 left-0 bg-midnight/90 border border-white/10 p-3 rounded-lg text-[9px] font-mono text-electric shadow-2xl"
      >
        <div className="text-white/40 mb-1">// global_sync.js</div>
        <div>const sync = async () ={" > "} {'{'}</div>
        <div className="pl-2">await cloud.distribute();</div>
        <div className="text-cyan">{'}'}</div>
      </motion.div>

      {/* Falling Data Bits */}
      <div className="absolute inset-0 overflow-hidden opacity-20">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            initial={{ y: -100, x: Math.random() * 600 - 300, opacity: 0 }}
            animate={{ y: 600, opacity: [0, 1, 0] }}
            transition={{ duration: 4 + Math.random() * 4, repeat: Infinity, delay: Math.random() * 10 }}
            className="absolute text-[8px] font-mono text-cyan"
          >
            {Math.random() > 0.5 ? "1" : "0"}
          </motion.div>
        ))}
      </div>
    </div>
  );
};

const Hero = ({ setActivePage }: { setActivePage: (page: string) => void }) => {
  return (
    <section className="relative min-h-screen bg-midnight flex items-center pt-24 overflow-hidden">
      {/* Psychology: Depth & Dynamic Motion (Confidence) */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div 
          animate={{ 
            scale: [1, 1.1, 1],
            opacity: [0.2, 0.3, 0.2],
            x: [0, 40, 0],
            y: [0, -20, 0]
          }}
          transition={{ duration: 18, repeat: Infinity, ease: "easeInOut" }}
          className="absolute top-1/4 -left-20 w-[600px] h-[600px] bg-electric/15 rounded-full blur-[140px]"
        />
        <motion.div 
          animate={{ 
            scale: [1, 1.2, 1],
            opacity: [0.15, 0.25, 0.15],
            x: [0, -40, 0],
            y: [0, 40, 0]
          }}
          transition={{ duration: 22, repeat: Infinity, ease: "easeInOut" }}
          className="absolute bottom-1/4 -right-20 w-[700px] h-[700px] bg-cyan/10 rounded-full blur-[160px]"
        />
        <div className="absolute inset-0 opacity-[0.02]" style={{ backgroundImage: 'radial-gradient(#fff 1px, transparent 1px)', backgroundSize: '50px 50px' }} />
      </div>

      <div className="max-w-7xl mx-auto px-6 relative z-10 grid lg:grid-cols-2 gap-20 items-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1] }}
          className="relative z-20"
        >
          <h1 className="text-6xl md:text-8xl font-extrabold text-white mb-10 text-balance tracking-tight">
            Scale with <span className="text-electric">Absolute</span> Authority.
          </h1>
          <p className="text-xl md:text-2xl text-white/50 mb-12 max-w-xl leading-relaxed font-light">
            ITGS engineers psychology-driven technology solutions for the world's most ambitious enterprise brands.
          </p>
          <div className="flex flex-wrap gap-6">
            <button onClick={() => setActivePage('Booking')} className="btn-primary group">
              Get Started Now
              <ArrowRight size={22} className="group-hover:translate-x-1.5 transition-transform duration-300" />
            </button>
            <button onClick={() => setActivePage('Booking')} className="btn-outline">Speak with an Expert</button>
          </div>

          {/* Psychology: Immediate Social Proof (Trust) */}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95, rotateY: -10 }}
          animate={{ opacity: 1, scale: 1, rotateY: 0 }}
          transition={{ duration: 1.8, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
          className="relative hidden lg:block perspective-2000"
        >
          <TechVisual />
        </motion.div>
      </div>
    </section>
  );
};

const ServicesPreview = ({ setActivePage }: { setActivePage: (page: string) => void }) => {
  return (
    <section className="section-padding bg-starfield relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-32">
          <Reveal>
            <span className="text-electric font-bold uppercase tracking-[0.4em] text-xs mb-6 block">Core Expertise</span>
            <h2 className="text-6xl md:text-7xl font-extrabold mb-8 text-balance">Engineered for <span className="text-electric">Impact.</span></h2>
            <p className="text-steel/70 max-w-2xl mx-auto text-xl font-light leading-relaxed">
              Our suite of services is designed to provide the authority and reliability your global brand demands.
            </p>
          </Reveal>
        </div>
        <StaggerContainer>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {SERVICES_DATA.slice(0, 4).map((s, i) => (
              <div key={i}>
                <StaggerItem>
                  <div className="card-premium group h-full flex flex-col">
                    <div className="w-20 h-20 bg-starfield rounded-2xl flex items-center justify-center text-cyan mb-8 group-hover:bg-electric group-hover:text-white transition-all duration-700 shadow-inner">
                      {s.icon}
                    </div>
                    <h3 className="text-2xl font-bold mb-4 group-hover:text-electric transition-colors">{s.title}</h3>
                    <p className="text-steel/80 text-sm leading-relaxed font-light mb-8 flex-grow">{s.shortDesc}</p>
                    
                    <button 
                      onClick={() => setActivePage(`Service:${s.id}`)}
                      className="pt-6 border-t border-midnight/5 flex items-center gap-3 text-xs font-bold uppercase tracking-widest text-black hover:text-electric transition-colors mt-auto"
                    >
                      Learn More <ArrowRight size={14} className="group-hover:translate-x-2 transition-transform duration-300" />
                    </button>
                  </div>
                </StaggerItem>
              </div>
            ))}
          </div>
        </StaggerContainer>
        <div className="mt-20 text-center">
          <button onClick={() => setActivePage('Services')} className="btn-outline">View All Services</button>
        </div>
      </div>
    </section>
  );
};

const ResultsSection = () => {
  return (
    <section className="section-padding bg-deep-blue relative overflow-hidden">
      {/* Psychology: High-Contrast Data (Authority) */}
      <div className="absolute inset-0 opacity-20 pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, #2196F3 1px, transparent 0)', backgroundSize: '40px 40px' }} />

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="grid lg:grid-cols-2 gap-32 items-center">
          <div>
            <Reveal>
              <span className="text-cyan font-bold uppercase tracking-[0.4em] text-xs mb-8 block">Measurable Success</span>
              <h2 className="text-6xl font-extrabold text-white mb-10 leading-tight text-balance">Results that <span className="text-electric">Define</span> Industries.</h2>
              <p className="text-white/40 text-xl mb-16 font-light leading-relaxed">
                We deliver the technical precision and psychological insight required to dominate global markets.
              </p>
            </Reveal>
            <StaggerContainer delay={0.4}>
              <div className="grid grid-cols-2 gap-16">
                {[
                  { label: "Global Clients", val: "500+" },
                  { label: "Retention Rate", val: "98%" },
                  { label: "Revenue Impact", val: "$2B+" },
                  { label: "Expert Support", val: "24/7" },
                ].map((item, i) => (
                  <div key={i}>
                    <StaggerItem>
                      <div className="text-6xl font-extrabold text-white mb-4 tracking-tighter">{item.val}</div>
                      <div className="text-cyan text-xs uppercase tracking-[0.3em] font-bold">{item.label}</div>
                    </StaggerItem>
                  </div>
                ))}
              </div>
            </StaggerContainer>
          </div>
          
          <Reveal delay={0.6}>
            <div className="bg-white/5 backdrop-blur-3xl p-16 rounded-[3.5rem] border border-white/10 shadow-3xl">
              <div className="flex items-center gap-8 mb-16">
                <div className="w-20 h-20 rounded-3xl bg-electric/20 flex items-center justify-center text-electric shadow-inner">
                  <BarChart3 size={40} />
                </div>
                <div>
                  <div className="text-white text-2xl font-bold">Enterprise Velocity</div>
                  <div className="text-white/30 text-xs uppercase tracking-widest mt-2">Real-time performance auditing</div>
                </div>
              </div>
              <div className="space-y-12">
                {[
                  { label: "System Efficiency", val: 94 },
                  { label: "Security Integrity", val: 100 },
                  { label: "User Engagement", val: 87 },
                ].map((item, i) => (
                  <div key={i}>
                    <div className="flex justify-between text-white/70 text-sm mb-5 font-bold tracking-wider uppercase">
                      <span>{item.label}</span>
                      <span className="text-cyan">{item.val}%</span>
                    </div>
                    <div className="h-2 bg-white/5 rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        whileInView={{ width: `${item.val}%` }}
                        transition={{ duration: 2.5, delay: i * 0.4, ease: [0.22, 1, 0.36, 1] }}
                        className="h-full bg-gradient-to-r from-electric to-cyan"
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
};

const WhyChooseSection = () => {
  return (
    <section className="section-padding bg-starfield relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-24 items-center">
        <Reveal width="fit-content">
          <div className="order-2 lg:order-1 relative">
            <div className="absolute -inset-4 bg-electric/5 rounded-[3rem] blur-3xl -z-10" />
            <img 
              src="https://picsum.photos/seed/itgs-tech/800/600" 
              alt="Technology Innovation" 
              className="rounded-[3rem] shadow-2xl border border-midnight/5"
              referrerPolicy="no-referrer"
            />
            {/* Floating Badge */}
            <motion.div 
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 4, repeat: Infinity }}
              className="absolute -bottom-10 -right-10 bg-starfield p-8 rounded-3xl shadow-2xl border border-midnight/5 hidden md:block"
            >
              <div className="text-electric font-black text-4xl mb-1">99.9%</div>
              <div className="text-steel/60 text-xs uppercase tracking-widest font-bold">Uptime Guaranteed</div>
            </motion.div>
          </div>
        </Reveal>

        <div className="order-1 lg:order-2">
          <Reveal>
            <span className="text-electric font-bold uppercase tracking-[0.4em] text-xs mb-8 block">The ITGS Advantage</span>
            <h2 className="text-5xl md:text-6xl font-extrabold mb-10 leading-tight">Why Industry Leaders <span className="text-electric">Choose ITGS.</span></h2>
          </Reveal>
          <StaggerContainer delay={0.3}>
            <div className="space-y-12">
              {[
                { title: "Psychology-Driven Approach", desc: "We understand the human element behind every interaction, building trust through intuitive design." },
                { title: "Uncompromising Reliability", desc: "Our systems are built for 99.99% uptime, ensuring your business never misses a beat." },
                { title: "Future-Proof Innovation", desc: "We stay ahead of the curve, integrating the latest AI and blockchain technologies seamlessly." },
              ].map((item, i) => (
                <div key={i}>
                  <StaggerItem>
                    <div className="flex gap-8 group">
                      <div className="w-16 h-16 rounded-2xl bg-starfield flex-shrink-0 flex items-center justify-center text-electric font-black text-2xl shadow-inner group-hover:bg-electric group-hover:text-white transition-all duration-500">
                        0{i + 1}
                      </div>
                      <div>
                        <h3 className="text-2xl font-bold mb-3 group-hover:text-electric transition-colors">{item.title}</h3>
                        <p className="text-steel/70 text-lg leading-relaxed font-light">{item.desc}</p>
                      </div>
                    </div>
                  </StaggerItem>
                </div>
              ))}
            </div>
          </StaggerContainer>
        </div>
      </div>
    </section>
  );
};

const Reveal = ({ children, width = "w-full", delay = 0.25 }: { children: React.ReactNode, width?: "w-full" | "fit-content", delay?: number }) => {
  return (
    <div className={`relative ${width}`}>
      <motion.div
        variants={{
          hidden: { opacity: 0, y: 40 },
          visible: { opacity: 1, y: 0 },
        }}
        initial="hidden"
        whileInView="visible"
        transition={{ duration: 0.7, delay, ease: [0.22, 1, 0.36, 1] }}
        viewport={{ once: true, margin: "-100px" }}
      >
        {children}
      </motion.div>
    </div>
  );
};

const StaggerContainer = ({ children, delay = 0 }: { children: React.ReactNode, delay?: number }) => {
  return (
    <motion.div
      variants={{
        hidden: { opacity: 0 },
        visible: {
          opacity: 1,
          transition: {
            staggerChildren: 0.15,
            delayChildren: delay,
          },
        },
      }}
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, margin: "-100px" }}
    >
      {children}
    </motion.div>
  );
};

const StaggerItem = ({ children }: { children: React.ReactNode }) => {
  return (
    <motion.div
      variants={{
        hidden: { opacity: 0, y: 30 },
        visible: { opacity: 1, y: 0 },
      }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </motion.div>
  );
};

const TestimonialsSection = () => {
  const reviews = [
    { name: "Sarah Jenkins", role: "CTO, Global Logistics", text: "ITGS transformed our legacy systems into a high-velocity engine. Their psychological approach to UX is a game-changer." },
    { name: "David Chen", role: "VP Engineering, FinTech Pro", text: "The most reliable tech partner we've ever worked with. Their security architecture is second to none." },
    { name: "Marcus Thorne", role: "Director of Innovation, NexGen", text: "Scaling was our biggest hurdle until ITGS stepped in. They don't just build; they architect success." },
  ];

  return (
    <section className="section-padding bg-starfield relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="text-center mb-24">
          <Reveal>
            <span className="text-electric font-bold uppercase tracking-[0.4em] text-xs mb-6 block">Client Success</span>
            <h2 className="text-5xl md:text-6xl font-extrabold mb-8">Trusted by the <span className="text-electric">Best.</span></h2>
          </Reveal>
        </div>
        <StaggerContainer>
          <div className="grid md:grid-cols-3 gap-10">
            {reviews.map((r, i) => (
              <div key={i}>
                <StaggerItem>
                  <div className="bg-starfield p-12 rounded-[2.5rem] shadow-xl border border-midnight/5 relative group hover:-translate-y-2 transition-all duration-500 h-full">
                    <div className="text-electric mb-8">
                      {[...Array(5)].map((_, j) => <span key={j} className="text-2xl">★</span>)}
                    </div>
                    <p className="text-steel/80 text-xl italic leading-relaxed mb-10 font-light">"{r.text}"</p>
                    <div className="flex items-center gap-4 mt-auto">
                      <div className="w-14 h-14 rounded-full bg-midnight/5 flex items-center justify-center text-midnight font-bold text-xl">
                        {r.name[0]}
                      </div>
                      <div>
                        <div className="font-bold text-midnight">{r.name}</div>
                        <div className="text-steel/60 text-sm uppercase tracking-widest font-medium">{r.role}</div>
                      </div>
                    </div>
                  </div>
                </StaggerItem>
              </div>
            ))}
          </div>
        </StaggerContainer>
      </div>
    </section>
  );
};

const CTASection = ({ setActivePage }: { setActivePage: (page: string) => void }) => {
  return (
    <section className="section-padding bg-deep-blue relative overflow-hidden">
      {/* Psychology: Urgency & Directness */}
      <div className="absolute inset-0 bg-gradient-to-br from-electric/10 to-transparent" />
      <div className="max-w-5xl mx-auto px-6 relative z-10 text-center">
        <Reveal>
          <h2 className="text-6xl md:text-8xl font-extrabold text-white mb-10 leading-tight">Ready to <span className="text-electric">Dominate?</span></h2>
          <p className="text-white/50 text-2xl mb-16 max-w-2xl mx-auto font-light leading-relaxed">
            Join the global elite who rely on ITGS for psychology-driven technology that scales without limits.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-8">
            <button onClick={() => setActivePage('Booking')} className="btn-primary text-xl px-16 py-6 group">
              Start Your Transformation
              <ArrowRight size={24} className="group-hover:translate-x-2 transition-transform" />
            </button>
            <button onClick={() => setActivePage('Booking')} className="btn-outline text-xl px-16 py-6">
              Speak with an Expert
            </button>
          </div>
          <div className="mt-20 flex items-center justify-center gap-10 text-white/30 text-xs uppercase tracking-[0.3em] font-bold">
            <div className="flex items-center gap-2"><Shield size={16} /> Secure Integration</div>
            <div className="flex items-center gap-2"><Globe size={16} /> Global Deployment</div>
            <div className="flex items-center gap-2"><Zap size={16} /> Rapid Execution</div>
          </div>
        </Reveal>
      </div>
    </section>
  );
};

const Footer = ({ setActivePage }: { setActivePage: (page: string) => void }) => {
  return (
    <footer className="bg-deep-blue pt-20 pb-10 border-t border-white/5">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          <div>
            <div className="flex items-center gap-2 mb-6">
              <div className="w-8 h-8 bg-electric rounded flex items-center justify-center">
                <span className="text-white font-bold">I</span>
              </div>
              <span className="text-white font-display text-xl font-bold">ITGS</span>
            </div>
            <p className="text-white/40 leading-relaxed">
              The global authority in psychology-driven technology solutions for the modern enterprise.
            </p>
          </div>
          <div>
            <h4 className="text-white font-bold mb-6">Quick Links</h4>
            <ul className="space-y-4 text-white/40 text-sm">
              <li><button onClick={() => setActivePage('About')} className="hover:text-cyan transition-colors">About Us</button></li>
              <li><button onClick={() => setActivePage('Team')} className="hover:text-cyan transition-colors">Our Team</button></li>
              <li><button onClick={() => setActivePage('Careers')} className="hover:text-cyan transition-colors">Careers</button></li>
              <li><button onClick={() => setActivePage('Blog')} className="hover:text-cyan transition-colors">Blog</button></li>
            </ul>
          </div>
          <div>
            <h4 className="text-white font-bold mb-6">Services</h4>
            <ul className="space-y-4 text-white/40 text-sm">
              {SERVICES_DATA.slice(0, 4).map((s, i) => (
                <li key={i}>
                  <button 
                    onClick={() => setActivePage(`Service:${s.id}`)}
                    className="hover:text-cyan transition-colors text-left"
                  >
                    {s.title}
                  </button>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h4 className="text-white font-bold mb-6">Contact</h4>
            <ul className="space-y-4 text-white/40 text-sm">
              <li>contact@itgs.global</li>
              <li>+1 (800) ITGS-TECH</li>
              <li>Silicon Valley, CA</li>
              <li className="flex gap-4 pt-4">
                <div className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center hover:bg-cyan transition-colors cursor-pointer">
                  <Globe size={16} className="text-white" />
                </div>
                <div className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center hover:bg-cyan transition-colors cursor-pointer">
                  <Users size={16} className="text-white" />
                </div>
              </li>
            </ul>
          </div>
        </div>
        <div className="pt-10 border-t border-white/5 flex flex-col md:row justify-between items-center gap-4 text-white/20 text-xs uppercase tracking-widest">
          <p>© 2026 ITGS Global. All rights reserved.</p>
          <div className="flex gap-8">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

// --- Page Components ---

const AboutPage = () => (
  <div className="pt-32 pb-24 bg-starfield min-h-screen">
    <div className="max-w-7xl mx-auto px-6">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-20">
        <h1 className="text-5xl font-bold mb-6">Our Mission & Vision</h1>
        <p className="text-steel max-w-2xl mx-auto text-lg">
          Empowering the global enterprise through the perfect synergy of human psychology and advanced technology.
        </p>
      </motion.div>
      <div className="grid md:grid-cols-2 gap-12 items-center mb-24">
        <img src="https://picsum.photos/seed/itgs-about/800/600" alt="About ITGS" className="rounded-3xl shadow-xl" referrerPolicy="no-referrer" />
        <div>
          <h2 className="text-3xl font-bold mb-6">A Journey of Credibility</h2>
          <p className="text-steel mb-6 leading-relaxed">
            Founded in 2015, ITGS has grown from a specialized security firm into a global technology authority. Our journey is defined by a relentless pursuit of excellence and a deep understanding of how technology impacts the human experience.
          </p>
          <div className="grid grid-cols-2 gap-6">
            <div className="p-6 bg-starfield rounded-2xl border border-midnight/5">
              <div className="text-cyan font-bold text-2xl mb-1">2015</div>
              <div className="text-steel text-sm">Founded in SF</div>
            </div>
            <div className="p-6 bg-starfield rounded-2xl border border-midnight/5">
              <div className="text-cyan font-bold text-2xl mb-1">2019</div>
              <div className="text-steel text-sm">Global Expansion</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
);

const ReviewsPage = () => (
  <div className="pt-32 pb-24 bg-starfield min-h-screen">
    <div className="max-w-7xl mx-auto px-6">
      <div className="text-center mb-16">
        <h1 className="text-5xl font-bold mb-4">Trusted by Visionaries</h1>
        <p className="text-steel">Real stories from our global partners.</p>
      </div>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {[
          { name: "Sarah Jenkins", role: "CTO, Global Fin", text: "ITGS transformed our security posture. Their psychology-driven approach made adoption seamless across our 50,000 employees." },
          { name: "Marcus Chen", role: "VP Engineering, TechFlow", text: "The reliability of ITGS infrastructure is unmatched. We haven't seen a single minute of downtime since migrating." },
          { name: "Elena Rodriguez", role: "Director of UX, InnovateX", text: "Their understanding of human-centric design is profound. Our user engagement metrics have skyrocketed." },
        ].map((r, i) => (
          <div key={i} className="card-premium">
            <div className="flex gap-1 text-electric mb-4">
              {[1, 2, 3, 4, 5].map(s => <span key={s}>★</span>)}
            </div>
            <p className="text-midnight font-medium mb-6 italic">"{r.text}"</p>
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-full bg-midnight/5" />
              <div>
                <div className="font-bold">{r.name}</div>
                <div className="text-steel text-sm">{r.role}</div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  </div>
);

const TeamPage = () => (
  <div className="pt-32 pb-24 bg-starfield min-h-screen">
    <div className="max-w-7xl mx-auto px-6">
      <div className="text-center mb-16">
        <h1 className="text-5xl font-bold mb-4">The Minds Behind ITGS</h1>
        <p className="text-steel">A global team of experts dedicated to your success.</p>
      </div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
        {[
          { name: "Dr. Aris Thorne", role: "CEO & Founder", img: "https://picsum.photos/seed/person1/400/500" },
          { name: "James Wilson", role: "Chief Architect", img: "https://picsum.photos/seed/person2/400/500" },
          { name: "Lila Vance", role: "Head of Psychology", img: "https://picsum.photos/seed/person3/400/500" },
          { name: "Kenji Sato", role: "VP of Security", img: "https://picsum.photos/seed/person4/400/500" },
        ].map((m, i) => (
          <motion.div key={i} whileHover={{ scale: 1.02 }} className="group relative overflow-hidden rounded-3xl">
            <img src={m.img} alt={m.name} className="w-full aspect-[4/5] object-cover group-hover:scale-110 transition-transform duration-500" referrerPolicy="no-referrer" />
            <div className="absolute inset-0 bg-gradient-to-t from-midnight to-transparent opacity-80" />
            <div className="absolute bottom-0 left-0 p-6">
              <div className="text-white font-bold text-xl">{m.name}</div>
              <div className="text-cyan text-sm">{m.role}</div>
            </div>
            <div className="absolute inset-0 border-2 border-transparent group-hover:border-cyan/50 rounded-3xl transition-colors duration-500" />
          </motion.div>
        ))}
      </div>
    </div>
  </div>
);

const ServicesPage = ({ setActivePage }: { setActivePage: (page: string) => void }) => {
  return (
    <div className="pt-32 pb-24 bg-starfield min-h-screen">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-20">
          <Reveal>
            <h1 className="text-6xl font-extrabold mb-6">Our Core Solutions</h1>
            <p className="text-steel max-w-2xl mx-auto text-xl font-light">Deep-dive into the technology and strategy that powers the world's most ambitious brands.</p>
          </Reveal>
        </div>
        <StaggerContainer>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {SERVICES_DATA.map((s, i) => (
              <div key={i}>
                <StaggerItem>
                  <div className="card-premium group h-full flex flex-col">
                    <div className="w-20 h-20 bg-starfield rounded-2xl flex items-center justify-center text-cyan mb-8 group-hover:bg-electric group-hover:text-white transition-all duration-700 shadow-inner">
                      {s.icon}
                    </div>
                    <h3 className="text-2xl font-bold mb-4 group-hover:text-electric transition-colors">{s.title}</h3>
                    <p className="text-steel/80 text-sm leading-relaxed font-light mb-8 flex-grow">{s.shortDesc}</p>
                    
                    <button 
                      onClick={() => setActivePage(`Service:${s.id}`)}
                      className="pt-6 border-t border-midnight/5 flex items-center gap-3 text-xs font-bold uppercase tracking-widest text-black hover:text-electric transition-colors mt-auto"
                    >
                      Learn More <ArrowRight size={14} className="group-hover:translate-x-2 transition-transform duration-300" />
                    </button>
                  </div>
                </StaggerItem>
              </div>
            ))}
          </div>
        </StaggerContainer>
      </div>
    </div>
  );
};

const ServiceDetailPage = ({ serviceId, setActivePage }: { serviceId: string, setActivePage: (page: string) => void }) => {
  const service = SERVICES_DATA.find(s => s.id === serviceId);
  if (!service) return <div>Service not found</div>;

  return (
    <div className="bg-starfield min-h-screen">
      {/* Hero Section */}
      <section className="pt-48 pb-32 bg-deep-blue relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, #2196F3 1px, transparent 0)', backgroundSize: '40px 40px' }} />
        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <div className="grid lg:grid-cols-2 gap-20 items-center">
            <Reveal>
              <button 
                onClick={() => setActivePage('Services')}
                className="inline-flex items-center gap-2 text-cyan text-xs font-bold uppercase tracking-widest mb-8 hover:gap-4 transition-all"
              >
                <ArrowRight size={14} className="rotate-180" /> Back to Services
              </button>
              <h1 className="text-6xl md:text-7xl font-extrabold text-white mb-8 leading-tight">
                {service.title} <span className="text-electric">Redefined.</span>
              </h1>
              <p className="text-white/50 text-xl md:text-2xl mb-12 font-light leading-relaxed">
                {service.shortDesc}
              </p>
              <button onClick={() => setActivePage('Booking')} className="btn-primary px-12 py-5 text-lg">Request a Quote</button>
            </Reveal>
            <Reveal delay={0.4}>
              <div className="relative">
                <div className="absolute -inset-4 bg-electric/20 rounded-[3rem] blur-3xl" />
                <img 
                  src={`https://picsum.photos/seed/${service.id}/800/600`} 
                  alt={service.title} 
                  className="relative rounded-[3rem] shadow-2xl border border-white/10"
                  referrerPolicy="no-referrer"
                />
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* Overview Section */}
      <section className="section-padding bg-starfield">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-24 items-center">
            <Reveal>
              <span className="text-electric font-bold uppercase tracking-[0.4em] text-xs mb-8 block">Overview</span>
              <h2 className="text-4xl md:text-5xl font-extrabold mb-8 leading-tight">Strategic Value & <span className="text-electric">Impact.</span></h2>
              <p className="text-steel/70 text-xl leading-relaxed font-light">
                {service.overview}
              </p>
            </Reveal>
            <div className="grid grid-cols-2 gap-8">
              {service.features.map((f, i) => (
                <div key={i}>
                  <Reveal delay={0.2 * i}>
                    <div className="p-8 bg-starfield rounded-3xl border border-midnight/5 shadow-sm hover:shadow-md transition-shadow">
                      <div className="w-10 h-10 rounded-xl bg-electric/10 flex items-center justify-center text-electric mb-6">
                        <Zap size={20} />
                      </div>
                      <div className="font-bold text-midnight">{f}</div>
                    </div>
                  </Reveal>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="section-padding bg-starfield">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-24">
            <Reveal>
              <span className="text-electric font-bold uppercase tracking-[0.4em] text-xs mb-6 block">Our Methodology</span>
              <h2 className="text-5xl font-extrabold">How We Deliver <span className="text-electric">Excellence.</span></h2>
            </Reveal>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {service.process.map((p, i) => (
              <div key={i}>
                <Reveal delay={0.15 * i}>
                  <div className="relative group">
                    <div className="text-8xl font-black text-midnight/5 absolute -top-10 -left-4 group-hover:text-electric/10 transition-colors">0{i + 1}</div>
                    <div className="relative z-10">
                      <h3 className="text-2xl font-bold mb-4 text-midnight">{p.step}</h3>
                      <p className="text-steel/70 leading-relaxed">{p.desc}</p>
                    </div>
                  </div>
                </Reveal>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Results / Case Study */}
      <section className="section-padding bg-deep-blue text-white">
        <div className="max-w-5xl mx-auto px-6 text-center">
          <Reveal>
            <span className="text-cyan font-bold uppercase tracking-[0.4em] text-xs mb-8 block">Proven Results</span>
            <h2 className="text-5xl md:text-6xl font-extrabold mb-12">Measurable <span className="text-electric">Success.</span></h2>
            <div className="bg-white/5 backdrop-blur-xl p-16 rounded-[3.5rem] border border-white/10 shadow-2xl">
              <p className="text-2xl md:text-3xl font-light leading-relaxed italic mb-12">
                "{service.results}"
              </p>
              <div className="flex flex-wrap justify-center gap-12 pt-12 border-t border-white/5">
                {service.tools.map((t, i) => (
                  <div key={i} className="text-white/40 font-bold uppercase tracking-widest text-sm">{t}</div>
                ))}
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-padding bg-starfield">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <Reveal>
            <h2 className="text-5xl font-extrabold mb-8">Ready to Scale Your <span className="text-electric">Authority?</span></h2>
            <p className="text-steel/70 text-xl mb-12 font-light">
              Contact our experts today to discuss how our {service.title} solutions can transform your business.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-6">
              <button onClick={() => setActivePage('Booking')} className="btn-primary px-12 py-5 text-lg">Get Started</button>
              <button onClick={() => setActivePage('Services')} className="btn-outline px-12 py-5 text-lg">View Other Services</button>
            </div>
          </Reveal>
        </div>
      </section>
    </div>
  );
};

const BlogPage = () => {
  const [selectedCategory, setSelectedCategory] = useState('All');

  const blogPosts = [
    { title: "The Psychology of Trust in SaaS", date: "Oct 12, 2026", category: "UI/UX Design" },
    { title: "Scaling Infrastructure for 2027", date: "Oct 10, 2026", category: "Web Development" },
    { title: "AI Ethics in Global Enterprise", date: "Oct 05, 2026", category: "Digital Marketing" },
    { title: "Maximizing ROI with Technical SEO", date: "Sep 28, 2026", category: "Search Engine Optimization" },
    { title: "The Future of Mobile User Experience", date: "Sep 22, 2026", category: "Mobile App Development" },
    { title: "B2B Lead Gen: Beyond the Basics", date: "Sep 15, 2026", category: "Lead Generation" },
    { title: "E-commerce Trends for Global Markets", date: "Sep 08, 2026", category: "E-commerce Solutions" },
    { title: "Visual Identity in the Age of AI", date: "Sep 01, 2026", category: "Graphic Design" },
    { title: "Operational Excellence with Virtual Partners", date: "Aug 25, 2026", category: "Virtual Assistance" },
  ];

  const filteredPosts = selectedCategory === 'All' 
    ? blogPosts 
    : blogPosts.filter(post => post.category === selectedCategory);

  return (
    <div className="pt-32 pb-24 bg-starfield min-h-screen">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h1 className="text-5xl font-bold mb-4">Insights & Innovation</h1>
          <p className="text-steel">Expert perspectives on the future of technology.</p>
        </div>

        {/* Service Categories Section */}
        <div className="mb-20">
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            <button
              onClick={() => setSelectedCategory('All')}
              className={`px-6 py-3 border rounded-full text-sm font-bold transition-all duration-300 backdrop-blur-sm ${
                selectedCategory === 'All' 
                  ? 'bg-electric text-white border-electric shadow-lg shadow-electric/20' 
                  : 'bg-white/5 border-white/10 text-steel hover:text-electric hover:border-electric'
              }`}
            >
              All Insights
            </button>
            {SERVICES_DATA.map((service) => (
              <button
                key={service.id}
                onClick={() => setSelectedCategory(service.title)}
                className={`px-6 py-3 border rounded-full text-sm font-bold transition-all duration-300 backdrop-blur-sm ${
                  selectedCategory === service.title 
                    ? 'bg-electric text-white border-electric shadow-lg shadow-electric/20' 
                    : 'bg-white/5 border-white/10 text-steel hover:text-electric hover:border-electric'
                }`}
              >
                {service.title}
              </button>
            ))}
          </div>
          <div className="h-px bg-gradient-to-r from-transparent via-white/10 to-transparent mb-16" />
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredPosts.length > 0 ? (
            filteredPosts.map((b, i) => (
              <motion.div 
                key={b.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="card-premium flex flex-col"
              >
                <img src={`https://picsum.photos/seed/blog-${b.title}/600/400`} alt={b.title} className="rounded-xl mb-6" referrerPolicy="no-referrer" />
                <div className="text-cyan text-xs font-bold uppercase mb-2">{b.category}</div>
                <h3 className="text-xl font-bold mb-4 flex-grow">{b.title}</h3>
                <div className="flex justify-between items-center pt-6 border-t border-midnight/5">
                  <span className="text-steel text-sm">{b.date}</span>
                  <button className="text-electric font-bold text-sm hover:underline">Read More</button>
                </div>
              </motion.div>
            ))
          ) : (
            <div className="col-span-full text-center py-20">
              <p className="text-steel text-xl">No insights found for this category yet. Check back soon.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const CareersPage = () => (
  <div className="pt-32 pb-24 bg-starfield min-h-screen">
    <div className="max-w-7xl mx-auto px-6">
      <div className="text-center mb-20">
        <h1 className="text-5xl font-bold mb-6">Join the Authority</h1>
        <p className="text-steel max-w-2xl mx-auto">We're looking for visionaries who want to shape the future of global technology.</p>
      </div>
      <div className="grid lg:grid-cols-2 gap-12 mb-24">
        <div className="card-premium">
          <h2 className="text-2xl font-bold mb-6">Why Work With ITGS?</h2>
          <ul className="space-y-4">
            {["Global Impact", "Innovative Culture", "Continuous Learning", "Premium Benefits"].map((item, i) => (
              <li key={i} className="flex items-center gap-3">
                <div className="w-6 h-6 rounded-full bg-cyan/10 flex items-center justify-center text-cyan">✓</div>
                <span className="text-steel font-medium">{item}</span>
              </li>
            ))}
          </ul>
        </div>
        <div className="space-y-6">
          <h2 className="text-2xl font-bold mb-6">Open Positions</h2>
          {[
            { role: "Senior Security Architect", loc: "Remote / SF" },
            { role: "Full Stack Engineer", loc: "London, UK" },
            { role: "UX Researcher (Psychology)", loc: "Remote" },
          ].map((j, i) => (
            <div key={i} className="p-6 bg-starfield rounded-2xl border border-midnight/5 flex justify-between items-center hover:border-electric transition-colors">
              <div>
                <div className="font-bold text-lg">{j.role}</div>
                <div className="text-steel text-sm">{j.loc}</div>
              </div>
              <button className="btn-primary py-2">Apply</button>
            </div>
          ))}
        </div>
      </div>
    </div>
  </div>
);

const BookingPage = () => (
  <div className="pt-32 pb-24 bg-starfield min-h-screen">
    <div className="max-w-7xl mx-auto px-6">
      <div className="text-center mb-12">
        <Reveal>
          <span className="text-electric font-bold uppercase tracking-[0.4em] text-xs mb-6 block">Direct Access</span>
          <h1 className="text-5xl md:text-6xl font-extrabold mb-8">Schedule Your <span className="text-electric">Strategy Session.</span></h1>
          <p className="text-steel max-w-2xl mx-auto text-lg font-light">
            Select a time that works for you to discuss your global technology requirements with our experts.
          </p>
        </Reveal>
      </div>
      
      <div className="card-premium p-0 overflow-hidden min-h-[700px] relative">
        <iframe 
          src="https://calendly.com/ammarzerobyte/30min?embed_domain=ais-dev-tarxpj7axqdr6ngbufwv5f-156932409613.asia-southeast1.run.app&embed_type=Inline"
          width="100%"
          height="700"
          frameBorder="0"
          title="Calendly Scheduling"
          className="w-full h-[700px]"
        ></iframe>
      </div>
    </div>
  </div>
);

// --- Main App ---

export default function App() {
  const [activePage, setActivePage] = useState('Home');

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [activePage]);

  return (
    <div className="min-h-screen bg-starfield">
      <Navbar activePage={activePage} setActivePage={setActivePage} />
      
      <main>
        {activePage === 'Home' && (
          <>
            <Hero setActivePage={setActivePage} />
            <ServicesPreview setActivePage={setActivePage} />
            <ResultsSection />
            <WhyChooseSection />
            <TestimonialsSection />
            <CTASection setActivePage={setActivePage} />
          </>
        )}
        {activePage === 'About' && <AboutPage />}
        {activePage === 'Services' && <ServicesPage setActivePage={setActivePage} />}
        {activePage.startsWith('Service:') && (
          <ServiceDetailPage 
            serviceId={activePage.split(':')[1]} 
            setActivePage={setActivePage} 
          />
        )}
        {activePage === 'Reviews' && <ReviewsPage />}
        {activePage === 'Team' && <TeamPage />}
        {activePage === 'Blog' && <BlogPage />}
        {activePage === 'Careers' && <CareersPage />}
        {activePage === 'Booking' && <BookingPage />}
      </main>

      <Footer setActivePage={setActivePage} />
    </div>
  );
}
